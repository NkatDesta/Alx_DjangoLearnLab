from bookshelf.models import Book
Book.objects.all()
# <QuerySet [<Book: 1984 by George Orwell (1949)>]>
